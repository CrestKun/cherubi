// Set the date of your girlfriend's birthday
const birthday = new Date("2023-04-16");

// Calculate the time remaining until her birthday
const now = new Date();
const timeDiff = birthday.getTime() - now.getTime();
const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

// Update the countdown element with the number of days remaining
const countdownElement = document.getElementById("countdown");
countdownElement.innerHTML = `${daysDiff}`;
